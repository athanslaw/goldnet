<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
  
	function category_details($id){
		$CI = & get_instance();
		$CI->load->model('post_mdl');
		$categorydetails = $CI->post_mdl->getcategorydetails($id);
		return $categorydetails;
	}
	
	function getPostCountByCategory($id){
		$CI = & get_instance();
		$CI->load->model('post_mdl');
		$categorydetails = $CI->post_mdl->getpost($id);
		return $categorydetails;
	}
	
   function founder(){
		$CI = & get_instance();
		$CI->load->model('Users_mdl');
		$founder = $CI->Users_mdl->founder();
		return $founder;
	}
	
	function getalert(){
		$CI = & get_instance();
		$CI->load->model('alert_mdl');
		$name = $CI->alert_mdl->viewalerts(0);
		return count($name);
	}
	
	function getCMS($id){
		$CI = & get_instance();
		$CI->load->model('page_model');
		$name = $CI->page_model->getcms($id);
		return $name;
	}
	
	function getCountry($id){
		$CI = & get_instance();
		$CI->load->model('users_mdl');
		$name = $CI->users_mdl->getCountry($id);
		return $name;
	}
	
	function getLga($id){
		$CI = & get_instance();
		$CI->load->model('users_mdl');
		$name = $CI->users_mdl->getLga($id);
		return $name;
	}
	
	function getName($id){
		$CI = & get_instance();
		$CI->load->model('users_mdl');
		$name = $CI->users_mdl->getName($id);
		return $name;
	}
	
   function get_social_links(){
		$CI = & get_instance();
		$CI->load->model('Settings_mdl');
		$social_links_get = $CI->Settings_mdl->social_links_get();
		return $social_links_get;
	}
	
	function getState($id){
		$CI = & get_instance();
		$CI->load->model('users_mdl');
		$name = $CI->users_mdl->getState($id);
		return $name;
	}
	
	function lga($state){
		$CI = & get_instance();
		$name = $CI->page_model->lga(16);
		$option =  '<option value="">Please select...</option>';
		foreach($name as $row)
		{
			$option .= '<option value="'.$row['drink_name'].'">' . $row['drink_name'] . "</option>";
			//echo $row['drink_type'] ."<br/>";
		}
		return $option;
	}
	
	function social($id){
		$CI = & get_instance();
		$name = $CI->page_model->social($id);
		return $name;
	}

	function helper_job_type(){
		return $helper_job_type = array('1'=>'Full-Time','2'=>'Intern','3'=>'Contract');
	}
	
	function state($id){
		$CI = & get_instance();
		$name = $CI->page_model->state($id);
		return $name;
	}
	
	