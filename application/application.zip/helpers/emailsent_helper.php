<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 if( !function_exists('send_mail') ) {
	 
 function send_mail($to,$message,$title,$status,$subject) {
	   	
		//$this->load->library('My_PHPMailer');
		  
		$from_title = 'Lathan Info Tech Solutions';
        $mail = new PHPMailer();
        $mail->IsSMTP(); // we are going to use SMTP
        $mail->SMTPAuth   = true; // enabled SMTP authentication
       // $mail->SMTPSecure = "ssl";  // prefix for secure protocol to connect to the server
	   
        $mail->Host       = "mail.lathaninfotech.com.ng";      // setting GMail as our SMTP server
        $mail->Port       =  "25";                   // SMTP port to connect to GMail
        $mail->Username   = "admin@lathaninfotech.com.ng";  // user email address
        $mail->Password   = "athans333";            // password in GMail
        $mail->SetFrom('admin@lathaninfotech.com.ng', $from_title);  //Who is sending the email
        $mail->AddReplyTo("athans4sure@gmail.com",$title);  //email address that receives the response
		
        $mail->Subject    = $subject;
        $mail->Body      = $message;
        $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!";
		//$mail->AddEmbeddedImage(base_url().'assets/Frontend/images/logo.png', 'logo_2u');
		
        $mail->AddAddress($to, $title);

         //$mail->AddAttachment("images/phpmailer.gif");      // some attached files
      //  $mail->AddAttachment("images/phpmailer_mini.gif"); // as many as you want
        if(!$mail->Send()) {
             $data["message"] = "Error: " . $mail->ErrorInfo;
			  
        } else {
            $data["message"] = "Message sent correctly!";
			 
        } 
       // $this->load->view('sent_mail',$data);
	  // die;
    }
	
 }