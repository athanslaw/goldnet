<?php
class Login extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');//handles images
		$this->load->database();
        $this->load->helper('url_helper');
		$this->load->library('session');
        $this->load->model('Login_mdl');
		$this->data['pagess'] = $this->page_model->getpages(1);
		$this->data['favicon'] = base_url().'images/'.$this->page_model->getcms('icon');
		$this->data['logo'] = base_url().'images/'.$this->page_model->getcms('logo');
		$this->data['postcategory'] = $this->post_mdl->getcategory(1);
	}
	
	public function index(){
		$this->data['content'] = 'Supply your signin credentials here';
		$this->data['class'] = 'alert alert-warning';
		if($_POST){
 			$this->Login_mdl->check_admin_login();
			$this->data['content']=$this->session->flashdata('error');
 		}
		
		$this->data['title']=founder()->short_name.' - User Login';
		
		$this->load->view('general/header', $this->data);
        $this->load->view('general/login', $this->data);
		$this->load->view('general/footer', $this->data);
	}
}