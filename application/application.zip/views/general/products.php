  <body>   
        <div class="container">
		<div class="row"><div class="col-sm-1 col-md-1"></div><div class="col-sm-10 col-md-10 boxed  sticky  push-down-45">
            <div class="row"><div class="col-sm-1 col-md-1"></div><div class="col-sm-10 col-md-10">
	<div align="center"><br><a href="#"><img src="<?=base_url()?>images/whoweare.png" height="250px" /></a></div>
	<div class="h1">Products and Services</div>
			
            <span class="italic" style="text-align:left"> 
			
			
		<h2><span style="color:#000066">Our Services</span></h2>
		At Lathan Info Tech Solutions, we guarantee the best services in terms of quality of products, cost of service and speed of delivery. 
		Our solutions span a wide range of sectors and organizations including the agricultural, health, social, technological, religious, governmental,
Non-Governmental Organizations and others.
		We develop, custom applications for your unique specifications and we deliver the best when in comes to IT solutions.
		The list of our solutions are endless, a trial will convince you. <img src="<?=base_url()?>images/lathanmotto.gif" height="20px" />
		<h3>We offer consultancy services on the following:</h3>
		<img src="<?=base_url()?>images/computerconsultancy.jpg" style="float:right; padding-left:10px" class="img img-responsive" />
		<ul style="padding-left:20px"><li>Client Server Applications Development</li>
		<li>ICT Infrastructure Development</li>
		<li>Internet (web) Applications Development</li>
		<li>Software maintenance and  implementation support</li>
		<li>Software Re-Engineering</li>
		<li>Data Processing services</li>
		<li>DBA (database administration) services (MySQL Server), performance tuning and high-availability planning</li>
		<li>DataBase migration from one platform to another</li>
		<li>Corporate Training</li></ul>

		<h3>Networking and Internet Access</h3>

<img src="<?=base_url()?>images/mobil.jpg" height="96" /><br />
Our portal solutions and related web applications run on the internet and in some cases, 
a local Area Network for some clients, therefore, we deploy ICT infrastructures that enable them to run a portal. To meet these customers and provide a one-stop, integrated solution suite, we have developed core competence in the following areas:

<ul style="padding-left:20px"><li>Supply of computers and accessories</li>
<li>Network design and implementation</li>
<li>VSAT equipment installation</li>
<li>Internet Access</li>
<li>Technical support and ICT equipment maintenance</li></ul>
 
<h3>Website / Blog Design and Hosting</h3>

<img src="<?=base_url()?>images/webdesign.jpg" width="143" /><br />
We design websites and host them in secured internet servers. Our designs are world-class and we incorporate some other value added services for your consumption.<br />

For more information <a href="<?=base_url()?>contact">contact us </a>
      

        <div class="article">
          <h2><span>Lathan</span> Software Solutions</h2>
          <div class="clearfix"></div>
          <div class="img"><img src="<?=base_url()?>images/LawrenceDashboard.jpg" alt="BI Dashboards and Reports" style="float:left; padding-bottom:10px" class="image" /></div>
          <div class="post_content"><strong>LATHAN BI (Business Intelligence).</strong> 
		  Business Intelligence Application with professional UI & UX Design, Secure Backend API Development, Data Harvesting and beautiful dashboards and reports
.
          <br /><br/>
        </div>
        
          <div class="clearfix"></div>
          <div class="img"><img src="<?=base_url()?>images/school.png" alt="School Portal" style="float:left; padding-bottom:10px" class="image" /></div>
          <div class="post_content"><strong>LATHAN School Solution.</strong> 
		  A school management system for elementary, secondary, tertiary and professional institutions. It handles all the operations performed in an institution automatically 
		  thereby making the school system more effective, efficient and error free.
          <br /><a href="http://www.schoolportal.net.ng" target="_blank">www.schoolportal.net.ng</a>
        </div>
		<div class="clearfix"></div>
<hr style="color:#00FFFF" />        
        <div class="img"><img src="<?=base_url()?>images/pilgrims.jpg" width="250" height="83" alt="" class="fl" style="float:left; padding-right:10px" /></div>
          <div class="post_content">
          <strong>LATHAN Christian Pilgrim Welfare System.</strong> A portal that processes the application, recruitment and welfare of christian pilgrims.
          </div>
          <div class="clearfix"></div>
		  To view more of our products go to <a href="<?=base_url()?>page/Our_Projects">Our Projects</a>
          <div class="clearfix"></div>
      </div>
      <div class="article"><br>
      <h4>We provide solutions and services with the following technologies: </h4>
		<img src="<?=base_url()?>images/framework.png" class="technology" alt="jquery" title="Framework" height="100px">
        <img src="<?=base_url()?>images/html5.jpg" class="technology" alt="html5" title="Html5" height="100px">
        <img src="<?=base_url()?>images/android-1.jpg" class="technology" alt="android" title="Android" height="100px">
        <img src="<?=base_url()?>images/icon_FlshMovie.gif" class="technology" alt="flash animation" title="Flash" height="100px">
        <img src="<?=base_url()?>images/logo.gif" class="technology" alt="Java EE" title="Java EE"></div>
		<p>&nbsp;</p>
      </div>
			
 </span></div></div></div><div class="col-sm-1 col-md-1"></div></div>