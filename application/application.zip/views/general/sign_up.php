
<section class="inner_page_wrap">

	<div class="container">
    	<h1 class="title2">Join <?=founder()->name?>. It's fast, easy and free.</h1>
    	<div class="row sign_up_form">
        	<div class="col-md-5">
            	<div class="social_connect">
                	<a class="fb_btn" href="#"><i class="fa fa-facebook-f"></i> Connect with Facebook</a>
                    <a class="gp_btn" href="#"><i class="fa fa-google-plus"></i> Connect with Google+</a>
                </div>
            </div>
            <div class="col-md-7">
            	<form>
                  <div class="form-group">
                    <input type="text" class="form-control" id="exampleInputname" placeholder="First Name">
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" id="exampleInputLname" placeholder="Last Name">
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email">
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control" id="exampleInputPasswordC" placeholder="Confirm Password">
                  </div>
                  <div class="checkbox">
                    <label>
                      <input type="checkbox"> Send me <?=founder()->name?> newsletters, weekly information and advice on all aspects of running my business 
                    </label>
                  </div>
                  <button type="submit" class="btn grn_btn">Sign Up</button>
                  <div class="alrdy_mem">Already a member? <a href="#">Sign in</a></div>
                </form>
                <div class="clearfix"></div>
                
            </div>
        </div>
    </div>

</section>
