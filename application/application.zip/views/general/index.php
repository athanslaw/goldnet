
<!--Slider Section Start-->
<section id="slider-wrap" class="clear">
<div class="slider-inner outer-width">

<!--Main Slider start-->
<div id="slider" class="carousel slide" data-ride="carousel">

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?=base_url()?>/images/goldnetbanner1.jpg" alt="Slider Image">
      <div class="carousel-caption">
        <div class="big_txt"><span>Promote</span> your Brand <br><span>Market</span> Yourself <br><span>Get</span> Informed</span></div>
        <br><a href="#" class="grn_btn">Join today & get a welcome bonus</a>
      </div>
    </div>
    <div class="item">
      <img src="<?=base_url()?>/images/slider_img1.jpg" alt="Slider Image">
      <div class="carousel-caption">
        <div class="big_txt"><span>What</span> Value <br>do you<span> Bring</span>  <br><span>to the</span> Market?</span></div>
        <br><a href="#" class="grn_btn">Join today & Sell yourself</a>
      </div>
    </div>
    
  </div>
  
  <!--Controls -->
  <!--<div class="controls-wrap">
      <a class="left carousel-control" href="#slider" role="button" data-slide="prev">
        <i class="fa fa-chevron-circle-left"></i>
      </a>
      <a class="right carousel-control" href="#slider" role="button" data-slide="next">
        <i class="fa fa-chevron-circle-right"></i>
       </a>
	</div>-->
	<!--Controls End-->    
    
</div>
<!--Main Slider end-->

</div>
</section>
<!--Slider Section End-->

<section id="search_section" class="clear">
	<a class="mouse" href="#search_section"><img src="<?=base_url()?>images/mouse_icon.png" alt=""/></a>
	<div class="container">
    	<h1 class="title">Africa's Global Marketer</h1>
        <span class="sub-title">Find great products around the corner and across the World.</span>
    	<div class="search_box">
        	<form class="form-inline">
                <input type="text" class="form-control" id="find1" placeholder="Find Product, Service , Businesses">
                <input type="text" placeholder="Location" id="find2" class="form-control">
              <button type="submit" class="btn btn-default">Search</button>
            </form>
        </div>
        <div class="btns_block">
        	<a class="green_btn" href="#">+ Add My Brand</a>
            <a class="black_btn" href="#">Learn More</a>
        </div>
    </div>
</section>

<section id="services_section" class="container clear">
	<div class="row-fluid">
    	<div class="col-md-4 col-sm-4">
        	<div class="ser_box">
            	<img src="<?=base_url()?>images/digital_icon.png" alt="Digital marketing solutions"/>
                <h3>Digital marketing solutions</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse eu interdum velit, a ornare ligula. Nulla cursus vehicula turpis, sollicitudin tcursus nisi.</p>
                <a href="#">more &gt;&gt;</a>
            </div>
        </div>
        <div class="col-md-4 col-sm-4">
        	<div class="ser_box">
            	<img src="<?=base_url()?>images/web_icon.png" alt="Digital marketing solutions"/>
                <h3>Professional Profiling</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse eu interdum velit, a ornare ligula. Nulla cursus vehicula turpis, sollicitudin tcursus nisi.</p>
                <a href="#">more &gt;&gt;</a>
            </div>
        </div>
        <div class="col-md-4 col-sm-4">
        	<div class="ser_box last">
            	<img src="<?=base_url()?>images/profe_icon.png" alt="Digital marketing solutions"/>
                <h3>Professional consulting services</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse eu interdum velit, a ornare ligula. Nulla cursus vehicula turpis, sollicitudin tcursus nisi.</p>
                <a href="#">more &gt;&gt;</a>
            </div>
        </div>
    <div class="clearfix"></div>
    </div>
</section>


<section id="sector_section" class="clear">
	<div class="container">
	<div class="row-fluid">
    	<div class="col-md-12">
        	<h1 class="title2">Access our Online Library by Category</h1>
        </div>
		
		
		<?php $ttlNo = count($categories)/4; ?>
		
    	<div class="col-md-3 col-sm-6 col-xs-6">
        	<ul class="sector_list">
				<?php
					for($i = 0; $i < $ttlNo; $i += 1){
				?>
                <li><a href="<?php echo base_url().'books/'.$categories[$i]['id']; ?>"> <?=$categories[$i]['name'] ?> <span>(<?=count(getPostCountByCategory($categories[$i]['id']))?>)</span></a></li>
				<?php } ?>
           </ul>
        </div>
		
    	<div class="col-md-3 col-sm-6 col-xs-6">
        	<ul class="sector_list">
				<?php
					for($i = $ttlNo; $i < $ttlNo*2; $i += 1){
						
				?>
                <li><a href="<?php echo base_url().'books/'.$categories[$i]['id']; ?>"> <?=$categories[$i]['name'] ?> <span>(<?=count(getPostCountByCategory($categories[$i]['id']))?>)</span></a></li>
				<?php //if() break; 
					}?>
           </ul>
        </div>
		
    	<div class="col-md-3 col-sm-6 col-xs-6">
        	<ul class="sector_list">
				<?php
					for($i = $ttlNo*2; $i < $ttlNo*3; $i += 1){
						
				?>
                <li><a href="<?php echo base_url().'books/'.$categories[$i]['id']; ?>"> <?=$categories[$i]['name'] ?> <span>(<?=count(getPostCountByCategory($categories[$i]['id']))?>)</span></a></li>
				<?php //if() break; 
					}?>
           </ul>
        </div>
		
    	<div class="col-md-3 col-sm-6 col-xs-6">
        	<ul class="sector_list">
				<?php
					for($i = $ttlNo*3; $i <= $ttlNo*4; $i += 1){
						
				?>
                <li><a href="<?php echo base_url().'books/'.$categories[$i]['id']; ?>"> <?=$categories[$i]['name'] ?> <span>(<?=count(getPostCountByCategory($categories[$i]['id']))?>)</span></a></li>
				<?php //if() break; 
					}?>
           </ul>
        </div>
     <div class="clearfix"></div>
    </div>
    </div>
</section>


<section id="state_section" class="clear">
	<div class="container">
	<div class="row-fluid">
    	<div class="col-md-12">
        	<h1 class="title2">Featured Daily Deals</h1>
        </div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
        
        
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
		<div class="col-md-2 col-sm-4 col-xs-4">
			<div class="business_block">
                	<div class="busi_details" style="width:150px; font-size:12px">
                        <ul class="busi_contact">
                            <li><a href="#">was 7.5%</a></li>
                            <li style="color:red; font-size:14px;">15.0% Cash Back</li>
                            <li><a href="#">Lathan InfoTech Solutions</a></li>
                        </ul>
                    </div>
            </div><!--business_block-->
		</div>
        
     <div class="clearfix"></div>
    </div>
    </div>
</section>

<section id="advert_section" class="container clear">
	<ul class="ads">
		<?php
		$no = 0;
					foreach($adverts as $advert){
		?>
    	<li><a href="<?=$advert->link?>" title="<?=$advert->title?>" target="_blank"><img class="img-responsive" src="<?=base_url()?>images/blog/advert/thumbnails/<?=$advert->image?>" alt=""/></a></li>
    	<!--<li><a href="#"><img class="img-responsive" src="<?=base_url()?>images/img1.png" alt=""/></a></li>-->
		<?php $no += 1;
					if($no == 3) break; }?>
    </ul>
</section>

<section id="green_box" class=" clear">
	<div class="container">
    	<h1>Find Or Add Your Brand Today!</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam convallis interdum neque ac molestie.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam convallis interdum neque ac molestie.</p>
        <a class="ylw_btn" href="#">+ Add Brand</a>
    </div>
</section>
