<link href="<?=base_url()?>css/main1.css" rel="stylesheet">
<body><style>
p{text-align:left}
</style>
	<div class="container">
			<div class="row">
			  <div class="col-xs-12  col-md-8">
				<div class="boxed  sticky  push-down-45">
				<?php  if($post->pix != '0') { ?>
					<div class="meta">
					  <img class="wp-post-image" src="<?php echo base_url()?>images/blog/books/coverpage/<?=$post->pix?>" alt="" width="748">
							<div class="meta__container">
								<div class="row">
									<div class="col-xs-12  col-sm-8">
										<div class="meta__info">
										<span class="meta__author"><img src="<?php echo base_url()?>images/blog/dummy-licensed/blog.jpg" alt="" width="30" height="30"> <a href="#"><?=founder()->short_name?></a> in <a href="#">News</a> </span>
										<span class="meta__date"><span class="fa fa-calendar"></span> &nbsp; <?php echo $post->id?></span>
										</div>
									</div>
										<div class="col-xs-12  col-sm-4">
											<div class="meta__comments">
												<span class="fa fa-comment"></span> &nbsp;
												<a href="single-post.html#disqus_thread"></a>
											</div>
										</div>
								</div>
							</div>
					</div>

					<div class="sticky__box">
						<span class="sticky__circle"></span>
						<span class="sticky__circle"></span>
						<span class="sticky__circle"></span>
						<span class="sticky__circle"></span>
					</div>
					<?php 
						}else{echo '<br><br>';}
							?>
		
							<div class="row">
								<div class="col-xs-10  col-xs-offset-1">
									<div class="post-content--front-page">
										<h2 class="front-page-title">
										<a href="#"><?php  echo $post->title ?></a>
										</h2>
                                        <p align="left">
											<?php echo $post->message ?>
										</p>
										<p>
											<div class="fb-like" data-href="<?= base_url().'article/'.$post->slug?>" data-layout="button_count"
											data-action="like" data-show-faces="true" data-share="true"></div>
											
										</p>
									</div>
								 <div class="<?=$class?>" onclick="this.style.display = 'none'"><?= $content?></div>
								 
<a href="<?= base_url().'images/blog/books/documents/'.$post->document_name?>" target="_blank" class="btn" style="background-color:#000045; color:white" name="comment">Download</a>
									<div class="read-more">
										<form action="" name="form1" method="post">
											<div class="post-content--front-page">
											<input type="hidden" value="<?php  echo $post->id ?>" name="id">
											<input type="text" name="name" class="form-control" placeholder="Full Name">
											<input type="email" name="email" class="form-control" placeholder="Email">
											<input type="text" name="website" class="form-control" placeholder="Website">
											<textarea class="form-control" rows="4" name="description" placeholder="Type your Comment Here"></textarea>
											<input type="submit" value="comment" class="btn-primary" name="comment">
											
											</div>
											
											<div class="post-content--front-page">
												<?php foreach($comment as $comment){ ?>
													<div><i><?php  echo $comment->description ?></i></div>
													<span class="meta__author"><img src="<?php echo base_url().founder()->image?>" alt="Meta avatar" width="30" height="30"> <a href="#"><?=$comment->name?></a></span>
												<?php }?>
											</div>
										</form>
									</div>
									
									
								</div>
							</div>
				</div>

					 
					</div>
 
