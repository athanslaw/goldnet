  <body>
    
 	<div class="clearfix"></div>
   
        <div class="container">
		
				<div class="boxed  sticky  push-down-45">
		<div class="row"><div class="col-sm-1"></div><div class="col-sm-10">
		<br>
            <h1>About the Founder </h1><p>&nbsp;</p>
            <div class="widget-author__image-container">
				<img class="widget-author__avatar" src="<?= base_url()?>images/founder/founder.jpg" alt="Founder image" width="110">
			</div>
			<p>&nbsp;</p>
			<span class="italic"> 
				<?=founder()->biography?>
				
			</span><p>&nbsp;</p></div>
		<div class="col-sm-1"></div>
            </div>
        </div>
        </div> <!-- container --> 
        