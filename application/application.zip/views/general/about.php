
<section class="inner_page_wrap">

	<div class="container">
    		
    	<div class="row about">
        	<div class="col-md-3">
            	<div class="side_bar">
                	<ul class="side_links">
                    	<li><a href="#"><i class="fa fa-angle-right"></i> Leaders</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> Board</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> Research</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-9 in_wrap">
            	<h1 class="title2">About <?=founder()->name?></h1>
                <b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut et bibendum mi. Mauris eleifend nec sapien id consectetur. Morbi ut turpis tortor. Pellentesque fringilla maximus dictum.</b>
                <ul class="re_links">
                    	<li><a href="#">Leaders</a></li>
                        <li><a href="#">Board</a></li>
                        <li><a href="#">Research</a></li>
                    </ul>
                 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut et bibendum mi. Mauris eleifend nec sapien id consectetur. Morbi ut turpis tortor. Pellentesque fringilla maximus dictum. Nam ac arcu laoreet leo congue malesuada ac quis nunc. In pretium nisl at nisi porttitor malesuada. Quisque metus lacus, lobortis tristique varius a, scelerisque sit amet magna. Nam tempus lacinia dui, ac aliquam est aliquam vitae. Ut volutpat fermentum ipsum, a sagittis risus egestas quis. Nunc mattis dolor arcu, vel condimentum ex scelerisque sed. Maecenas tempus ornare lacus sed pharetra. Sed sollicitudin rutrum leo. Mauris ultrices arcu vel tellus dapibus fringilla. In hac habitasse platea dictumst. Nullam commodo a tortor eu facilisis. Aenean in molestie urna, quis aliquam ante.</p>

<p>Donec dictum libero molestie orci mattis, in blandit lorem efficitur. Sed sollicitudin lobortis mauris, sed tempus dolor lacinia ut. Duis mollis tempus nulla, ut placerat leo pretium blandit. Curabitur fringilla elit ut felis sodales feugiat. Aenean sed felis bibendum erat viverra tempor. Sed maximus felis eget lorem lacinia ultrices. Cras ullamcorper sapien vitae accumsan eleifend.</p>

<p>In id pulvinar est. Duis urna purus, vulputate vitae fermentum et, commodo nec tortor. Pellentesque quis accumsan lacus. Nulla diam nunc, pretium id leo id, efficitur porttitor augue. Sed facilisis viverra mauris, in feugiat enim finibus at. Praesent non imperdiet augue. Praesent bibendum viverra arcu dignissim pharetra. Quisque in ex neque. Aenean felis justo, consectetur in euismod eu, maximus a arcu. Vestibulum eu nibh est. Cras pharetra erat eu lectus mattis fermentum in in lectus. Aenean scelerisque augue eget nunc lacinia, vel sodales ipsum fringilla. </p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    
</section>
