
<section id="footer" class=" clear">
	<div class="container">
    	<div class="row">
        	<div class="col-md-4">
            	<h2>Quick Links</h2>
                <ul class="quick_links">
                	<li><a href="#"><i class="fa fa-angle-double-right"></i> Why <?=founder()->name?></a></li>
                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Contact <?=founder()->name?></a></li>
                    <li><a href="#"><i class="fa fa-angle-double-right"></i> FAQ's</a></li>
				</ul>
                <ul class="quick_links">
                	<li><a href="#"><i class="fa fa-angle-double-right"></i> About <?=founder()->name?></a></li>
                    <li><a href="#"><i class="fa fa-angle-double-right"></i> Technical Support</a></li>
				</ul>
            </div>
            <div class="col-md-3">
            	<h2>Contact Info</h2>
                <ul class="cont_link">
                    <li><a href="#"><i class="fa fa-envelope"></i> info@goldconsult.com.ng</a></li>
				</ul>
                <ul class="foot_social"><!--
                	<li><a href="#"><i class="fa fa-facebook"></i></a></li>-->
                    <li><a href="https://twitter.com/goldnetconsults"><i class="fa fa-twitter"></i></a></li><!--
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa fa-youtube"></i></a></li>-->
                </ul>
            </div>
            <div class="col-md-5">
            	<h2>Subscribe Our Newsletter</h2>
                <p>Get Latest updates by us on your email.</p>
                <div class="subscribe_box">
                	<input type="email" class="form-control" value="" placeholder="Your Email ID"/>
                    <button type="submit" class="form-control" value="" >Subscribe Now!</button>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row-fluid copy">
        	<div class="col-md-8 col-sm-8  col-xs-12">
            	&copy;<?=date('Y')?> <?=founder()->name?> , All Rights Reserved.
            </div>
            <div class="col-md-4 col-sm-4 col-xs-12">
            	<a href="<?=base_url()?>"><img src="<?=base_url()?>images/footer_logo.png" alt=""/></a>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</section>



</body>
<script src="<?=base_url()?>js/jquery.min.js"  type="text/javascript"></script><!--Library-->
<script src="<?=base_url()?>js/bootstrap.min.js"></script><!--Bootstrap-->
<script src="<?=base_url()?>js/custom.js" type="text/javascript"></script><!--Custom-->
</html>
