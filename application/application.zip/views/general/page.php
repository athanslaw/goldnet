<style>
p{text-align:left}
</style>
	<div class="container">
			<div class="row">
			  <div class="col-xs-12  col-md-8">
			  
				<div class="boxed  sticky  push-down-45">
				
					<div class="row">
						<div class="col-xs-10  col-xs-offset-1"><br><br>
							<h2 class="front-page-title"><?=$page->page_title?></h2>
							<p style="text-align:left">
							<?=$page->content?></p>

								</div>
							</div>
				</div>

					 
					</div>
 
