<section class="content-header">
      <h1>Edit Post</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Post</a></li>
        <li><a href="#">Edit Post</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-sm-12">
          
              
              

    <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
		<div class="col-sm-1"></div>
        <div class="col-sm-10">
        <div class="<?=$class?>"><?=$content?></div>
		
		
							<form action="" method="post" name="frm" enctype="multipart/form-data">
							<?php  if($post->pix != '0') { ?>
							<img id="blah" src="<?php echo base_url()?>images/blog/dummy/<?=$post->pix?>" alt="" width="153"><br><br>
							<?php }?>
								<input type="file" name="file" id="file" onchange="readURL(this);" /><br>
								
								<select name="category" required="required">
									<option value selected>-Select Category-</option>
									<?php
									foreach($categories as $categories){
									?>
										<option value="<?=$categories->id ?>" <?=($post->category!="" && $post->category == $categories->id )? "selected":"" ?> ><?=$categories->name ?>
										</option>
									<?php }?>
								</select><br><br>
								<input type="text" name="title" class="form-control" required="required" value="<?=$post->title?>" /><br>
								<!-- /.box-header -->
								<div class="box-body">
								  <div class="form-group">
										<textarea id="compose-textarea" class="form-control" name="message" style="height: 200px" required="required">
										<?=$post->message?>
										</textarea>
								  </div>
								</div>
								<!-- /.box-body -->
            					<input type="submit" name="submit" id="button" class="btn bg-primary" value="Submit" /><br><br>
							</form>
							
        </div><div class="col-sm-1"></div>            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
    
    
    
                </div>
                <!-- /.post -->
                </div>
                <!-- /.post -->

              </div>

              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  