<section class="content-header">
      <h1>Create</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Manage Page</a></li>
        <li><a href="#">Create Page</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-sm-12">
          
              
              

    <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
						<div class="col-sm-2"></div>
						<div class="col-sm-8"><div class="<?=$class?>"><?= $content?></div>
							<form action="" method="post" name="frm" enctype="multipart/form-data">
								<input type="text" name="title" class="form-control" placeholder="Page Title" required="required" /><br>
								<!-- /.box-header -->
								<div class="box-body">
								  <div class="form-group">
										<textarea id="compose-textarea" class="form-control" name="content" placeholder="Page Content" style="height: 200px" required="required">
										</textarea>
								  </div>
								</div>
								<!-- /.box-body -->
            					<input type="submit" name="send" id="button" class="btn bg-primary" value="Submit" /><br><br>
							</form>
						</div>
						<div class="col-sm-2"></div>
					</div>
				</div>
			</div>
		</div>
		
                <!-- /.post -->
                </div>
                <!-- /.post -->

              </div>

              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
		
		