        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span> Profile</span> <i class="fa fa-angle-left pull-right"></i>
          </a>
		  <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>myprofile"><i class="fa fa-circle-o"></i> View Profile</a></li>
		  </ul>
        </li>
		<li><a href="<?php echo base_url()?>admin/viewalert"><i class="fa fa-book"></i> <span> Notification<span class="badge"><?=getalert()?></span></span></a></li>
		<?php if($_SESSION['role']=='admin'){?>
		  <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Configuration</span> <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>admin/founder"><i class="fa fa-circle-o"></i> Founder Entry</a></li>
		  </ul>
		</li>
		<li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>CMS</span> <i class="fa fa-angle-left pull-right"></i>
          </a>
          <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>admin/logo"><i class="fa fa-circle-o"></i> Manage CMS</a></li>
		  </ul>
		</li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i>
            <span>Manage Library</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
		  <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>admin/viewcategory"><i class="fa fa-circle-o"></i> Manage Categories</a></li>
			<li><a href="<?php echo base_url()?>post"><i class="fa fa-circle-o"></i> Upload Article</a></li>
			<li><a href="<?php echo base_url()?>admin/myposts"><i class="fa fa-circle-o"></i> My Posts</a></li>
			<li><a href="<?php echo base_url()?>viewpost"><i class="fa fa-circle-o"></i> View All Articles</a></li>
			<!--<li><a href="<?php echo base_url()?>setfeaturedpost"><i class="fa fa-circle-o"></i> Featured Articles</a></li>-->
		  </ul>
        </li><!--
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i>
            <span>Manage Socials</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
		  <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>admin/sociallinks"><i class="fa fa-circle-o"></i> Configure Social Link</a></li>
			<li><a href="<?php echo base_url()?>admin/viewsocial"><i class="fa fa-circle-o"></i> View Social Links</a></li>
		  </ul>
        </li>-->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i>
            <span>Manage Advert</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
		  <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>admin/advert"><i class="fa fa-circle-o"></i> Post Advert</a></li>
			<li><a href="<?php echo base_url()?>admin/viewadvert"><i class="fa fa-circle-o"></i> View Adverts</a></li>
		  </ul>
        </li>
        
		<li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span>Manage Enquiries</span> <i class="fa fa-angle-left pull-right"></i>
          </a>
		  <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>viewenquiries"><i class="fa fa-circle-o"></i> View Enquiries</a></li>
		  </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span> Manage Users</span> <i class="fa fa-angle-left pull-right"></i>
          </a>
		  <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>admin/createuser"><i class="fa fa-circle-o"></i> Create Users</a></li>
			<li><a href="<?php echo base_url()?>users"><i class="fa fa-circle-o"></i> View Users</a></li>
		  </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i> <span> Manage Pages</span> <i class="fa fa-angle-left pull-right"></i>
          </a>
		  <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>admin/createpage"><i class="fa fa-circle-o"></i> Create Page</a></li>
			<li><a href="<?php echo base_url()?>admin/viewpages"><i class="fa fa-circle-o"></i> View Pages</a></li>
		  </ul>
        </li>
		<?php }
		else{?>
		
        <li class="treeview">
          <a href="#">
            <i class="fa fa-dashboard"></i>
            <span>Manage Post</span>
            <i class="fa fa-angle-left pull-right"></i>
          </a>
		  <ul class="treeview-menu">
			<li><a href="<?php echo base_url()?>post"><i class="fa fa-circle-o"></i> Create Post</a></li>
			<li><a href="<?php echo base_url()?>admin/myposts"><i class="fa fa-circle-o"></i> My Posts</a></li>
		  </ul>
        </li>
		<?php }?>
		<li><a href="<?php echo base_url()?>admin/changepass"><i class="fa fa-book"></i> <span> Change Password</span></a></li>
        <li><a href="<?php echo base_url()?>logout"><i class="fa fa-book"></i> <span>Logout</span></a></li>
		
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- =============================================== -->








  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">